package com.BankApplication;

import java.util.Scanner;

import com.BankApplicationModel.BankModel;
import com.Bankcontroller.Bankcontroller;
import static java.lang.System.*;

/**
 * 
 * 
 */
public class App{
	public static void main(String[] args) {
		Bankcontroller bc =new Bankcontroller();
		BankModel bm =new BankModel();
		Scanner sc =new Scanner(System.in);
		out.println("\t\t------Welcome to Secure Bank------");
		out.println("Enter your account Holdername");
		String accHolderName=sc.next();
        bm.setAccHolderName(accHolderName);
        try
        {
        	//validating username
        	if(bc.checkUsername(bm))
        	{
        		 out.println("Enter Password for your account ");
      	        String accPassword=sc.next();
      	        bm.setAccPassword(accPassword);
      	      try {
   	        	//validating password
   	        		if(bc.checkPassword(bm))
   	        		{
   	        			out.println("Enter account number ");
   	        	        int accNumber = sc.nextInt();
   	        	        bm.setAccNumber(accNumber);
   	        	        out.println("Enter Minimum balance");
   	        	        int accBalance=sc.nextInt();
   	        	            bm.setAccBalance(accBalance);
   	        	        out.println("------your details------");
   	                    out.println(bm.toString());
   	                    //performing baking operations
   	                   int op=0;
   	                    while(op<3)
   	                    {
   	                    out.println("Select Operation \n Press 1 for Deposit \n Press 2 for Withdraw \n Press 3 for details \\n Press 4 for exist");
   	                   op=sc.nextInt();
   	                    switch(op) {
   	                    //deposit method
   	                    case 1->
   	                    {
   	                    	out.println("Enter password to deposit");
   	                    	String pwd=sc.next();
   	                    	try {
   	                    		if(bc.toDeposit(bm, pwd)) 
   	                    		{
   	                    		out.println("Enter amount to deposit");
   	                    		int newAmt=sc.nextInt();
   	                    		bm.depositeAmount(newAmt);
   	                    		out.println("your account balance is :"+bm.getAccBalance());	
   	                    		}
   	                    	}
   	                    	catch(Exception e)
   	                    	{
   	                    		out.println(e.getMessage());
   	                    	}
   	                    	
   	                    }
   	                    //withdraw method
   	                    case 2->
   	                    
   	                    {
   	                    	out.println("Enter password to withdraw");
   	                    	String pwd=sc.next();
   	                    	out.println("Enter amount to withdraw");
	                    		int newAmt=sc.nextInt();
	                    		try {
	                    			if(bc.toWithdraw(bm, pwd, newAmt)) {
	                    				bm.withdrawAmount(newAmt);
	                    				out.println("Withdraw successfull \nyour account balance is : "+bm.getAccBalance());
	                    			}
	                    		}
	                    		catch(Exception e) {
	                    			out.println(e.getMessage());
	                    		}
   	                    }
   	                    case 3->
   	                    {
   	                    	out.println("***********your deatils***********");
   	                       out.println(bm.toString());
   	                    }
   	                    	default->System.exit(0);
   	                    
   	                    }
   	                    }
   	        		}
   	        }
   	        catch(Exception e) {
   	        	out.println(e.getMessage());
   	        }
   	}
   }
   catch(Exception e)
   {
   	out.println(e.getMessage());
   	System.exit(0);
   }
   
   
   
   sc.close();
        
		
		
		
	}
}

